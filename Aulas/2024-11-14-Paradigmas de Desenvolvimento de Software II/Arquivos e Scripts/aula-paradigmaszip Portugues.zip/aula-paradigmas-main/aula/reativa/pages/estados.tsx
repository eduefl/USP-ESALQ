import styles from "../styles/Home.module.css"; // Importa os estilos CSS

function ContadorComMensagem() {
  return <main className={styles.main}></main>;
}

export default ContadorComMensagem;
