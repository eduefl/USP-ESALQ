from pydantic import BaseModel
#from domain.user.user_entity import User
from typing import List
from uuid import UUID

# INPUT

class ListUsersInputDto(BaseModel):
    pass

# DTO INTERMEDIÁRIO
class UserDto(BaseModel):
    id: UUID
    name: str

# OUTPUT
class ListUsersOutputDto(BaseModel):
    users: List[UserDto]

# user_dto = UserDto(id=1, name="Alexandre") # ERRO (BaseModel vai validar)
# user_dto = UserDto(id=uuid4(), name="Mariana") # NÃO VAI DAR ERRO (BaseModel vai validar)