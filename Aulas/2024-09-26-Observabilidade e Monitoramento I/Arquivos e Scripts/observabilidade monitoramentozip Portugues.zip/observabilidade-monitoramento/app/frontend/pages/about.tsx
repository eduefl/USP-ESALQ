import React from "react";

export default function About() {
  return <div>Essa é a tela About</div>;
}
